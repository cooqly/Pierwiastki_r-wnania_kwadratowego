using System;
using Xunit;

namespace QuadraticEquationSolver.Tests
{
    public class ProgramTests
    {
        [Fact]
        public void SolveQuadraticEquation_NoRealRoots()
        {
            // Arrange
            double a = 2;
            double b = 3;
            double c = 4;

            // Act
            double[] result = Program.SolveQuadraticEquation(a, b, c);

            // Assert
            Assert.Empty(result);
        }

        [Fact]
        public void SolveQuadraticEquation_OneRealRoot()
        {
            // Arrange
            double a = 1;
            double b = -4;
            double c = 4;

            // Act
            double[] result = Program.SolveQuadraticEquation(a, b, c);

            // Assert
            Assert.Single(result);
            Assert.Equal(2, result[0], 2);
        }

        [Fact]
        public void SolveQuadraticEquation_TwoRealRoots()
        {
            // Arrange
            double a = 1;
            double b = -3;
            double c = -4;

            // Act
            double[] result = Program.SolveQuadraticEquation(a, b, c);

            // Assert
            Assert.Equal(2, result.Length);
            Assert.Equal(4, result[0], 2);
            Assert.Equal(-1, result[1], 2);
        }
    }
}
