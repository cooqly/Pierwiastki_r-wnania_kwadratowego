using System;

namespace QuadraticEquationSolver
{
    public class Program
    {
        public static void Main(string[] args)
        {
            double a, b, c;

            Console.WriteLine("Podaj współczynniki równania kwadratowego ax^2 + bx + c = 0");
            Console.Write("a: ");
            a = double.Parse(Console.ReadLine());

            Console.Write("b: ");
            b = double.Parse(Console.ReadLine());

            Console.Write("c: ");
            c = double.Parse(Console.ReadLine());

            double delta = b * b - 4 * a * c;

            if (delta < 0)
            {
                Console.WriteLine("Brak pierwiastków rzeczywistych.");
            }
            else if (delta == 0)
            {
                double x = -b / (2 * a);
                Console.WriteLine("Jeden pierwiastek rzeczywisty: x = " + x);
            }
            else
            {
                double x1 = (-b + Math.Sqrt(delta)) / (2 * a);
                double x2 = (-b - Math.Sqrt(delta)) / (2 * a);
                Console.WriteLine("Dwa pierwiastki rzeczywiste: x1 = " + x1 + ", x2 = " + x2);
            }
        }

        public static double[] SolveQuadraticEquation(double a, double b, double c)
        {
            double delta = b * b - 4 * a * c;

            if (delta < 0)
            {
                return new double[0]; // Brak pierwiastków rzeczywistych
            }
            else if (delta == 0)
            {
                double x = -b / (2 * a);
                return new double[] { x }; // Jeden pierwiastek rzeczywisty
            }
            else
            {
                double x1 = (-b + Math.Sqrt(delta)) / (2 * a);
                double x2 = (-b - Math.Sqrt(delta)) / (2 * a);
                return new double[] { x1, x2 }; // Dwa pierwiastki rzeczywiste
            }
        }
    }
}
